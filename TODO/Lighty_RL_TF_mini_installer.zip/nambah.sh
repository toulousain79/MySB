#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

####***********************************************####
#         Lighty HTTPD Addon Domain Plus Plus         #
#              Dark Eagle @ Kaskus.co.id              #
#              Based On 672727's Script               #
#          Supported By Regolithmedia.co.id           #
####***********************************************####

if [ $(id -u) != "0" ]; then
    echo "Error: Agans loginnya ga pake root neh. Udah, ganti dolo sanah jadi root, ada mi ayam sepesial tuh!"
    exit 0
fi
clear

echo "********************************************************************************"
echo "                      Lighty HTTPD Addon Domain Plus Plus"            
echo "********************************************************************************"
echo "                              Dark Eagle @ Kaskus"
echo "                   Discussion Thread At Hosting Stuff Kaskus"
echo "               http://www.kaskus.co.id/showthread.php?t=16720198"
echo "********************************************************************************"

echo "Type 'R' to install Rapidleech"
echo "Type 'T' to install Torrentflux"
echo "Type 'Z' to install rTorrent + RuTorrent"
while read -p "Please choose one [R/T/Z]: " dipilih
	do case $dipilih in
	R) [ "dipilih" = "$dipilih" ]; break;;
	r) [ "dipilih" = "$dipilih" ]; break;;
	T) [ "dipilih" = "$dipilih" ]; break;;
	t) [ "dipilih" = "$dipilih" ]; break;;
	Z) [ "dipilih" = "$dipilih" ]; break;;
	z) [ "dipilih" = "$dipilih" ]; break;;
	*) echo "";
	   echo "Please type your choice correctly!";;
	esac
done
echo ""

wwwdir=`cat /etc/lighttpd/wwwdir`
MARKAS=`ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk {'print $1'} | tail -n 1`

if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[tT]'` -gt 0 ]; then

GOO=0
YRT=1
AYA=mysql
while [ $GOO -eq "0" ]; do
read -p "Please input your MySQL root password: " mysqlrootpwd
CHECK=`/usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd --batch --skip-column-names -e "SHOW DATABASES LIKE 'mysql';"`
	if [ "$AYA" = "$CHECK" ]; then
		mysqlrootpwd="$mysqlrootpwd"
		GOO=1
	else if [ "$mysqlrootpwd" = "" ]; then
			if [ $YRT -lt 3 ]; then
				echo ""
				echo "You're not typing!"
				echo ""
				YRT=`expr $YRT + 1`
			else
				echo ""
				echo "You can try again later."
				echo ""
				exit 0
			fi
	else if [ "$AYA" != "$CHECK" ]; then
			if [ $YRT -lt 3 ]; then
				echo ""
				echo "You're typing wrong MySQL root password!"
				echo ""
				YRT=`expr $YRT + 1`
			else
				echo ""
				echo "You can try again later."
				echo ""
				exit 0
			fi
	fi
	fi
	fi	
done
echo ""

GOO=0
YRT=1
while [ $GOO -eq "0" ]; do
	read -p "Please input your preferred database name: " dbname
	ayaoi=`/usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd --batch --skip-column-names -e "SHOW DATABASES LIKE '$dbname';"`
	if [ "$dbname" = "$ayaoi" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "Database exist, please choose another one!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			exit 0
		fi
	else if [ "$dbname" = "" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "You're not typing!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			exit 0
		fi
	else
		GOO=1
	fi
	fi	
done
echo ""

GOO=0
YRT=1
while [ $GOO -eq "0" ]; do

OUTFILE=yy.txt
(
/usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd --batch --skip-column-names -e "SELECT user from mysql.user"; << EOF
EOF
) > $OUTFILE

read -p "Please input your preferred database user: " dbuser
if ! grep -q "$dbuser" "$OUTFILE"; then
	dbuser="$dbuser"
	GOO=1
else if [ "$dbuser" = "" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "You're not typing!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			rm -rf yy.txt
			exit 0
		fi
else if grep -q "$dbuser" "$OUTFILE"; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "Username exist, please choose another one!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			rm -rf yy.txt
			exit 0
		fi
	fi
fi
fi
done
rm -rf yy.txt
echo ""

GOO=0
YRT=1
while [ $GOO -eq "0" ]; do

	read -p "Please input your preferred database user password: " dbuserpass
	if [ "$dbuserpass" = "" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "You're not typing!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			exit 0
		fi
	else
		GOO=1
	fi
done

fi
	get_char()
	{
	SAVEDSTTY=`stty -g`
	stty -echo
	stty cbreak
	dd if=/dev/tty bs=1 count=1 2> /dev/null
	stty -raw
	stty echo
	stty $SAVEDSTTY
	}
	echo ""
	echo "Press any key to start the installation!"
	char=`get_char`
	

if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[rR]'` -gt 0 ]; then

	wget -O /usr/html/Rapidleech_PlugMod_v41.zip http://repo.regolithmedia.co.id/files/Rapidleech_PlugMod_v41.zip
	unzip -d /usr/html/ /usr/html/Rapidleech_PlugMod_v41.zip
	cd /usr/html
	mv Rapidleech\ PlugMod\ v41 rl
	cd /usr/html/rl
	chmod 777 files
	cd /usr/html/rl/configs
	chmod 777 *
	rm -rf /usr/html/Rapidleech_PlugMod_v41.zip

else if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[tT]'` -gt 0 ]; then

	wget -O /usr/html/torrentflux_2.4.tar.gz http://repo.regolithmedia.co.id/files/torrentflux_2.4.tar.gz
	tar -C /usr/html/ -zxvf/usr/html/torrentflux_2.4.tar.gz
	mv /usr/html/torrentflux_2.4 /usr/html/tf
	cd /usr/html/tf/html
	mv * /usr/html/tf
	cd /usr/html/tf
	
	echo 'CREATE DATABASE '$dbname';' | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
	echo "GRANT ALL PRIVILEGES ON $dbname.* TO '$dbuser'@'localhost' IDENTIFIED BY '$dbuserpass';" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
	echo "FLUSH PRIVILEGES;" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
	/usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd $dbname < /usr/html/tf/sql/mysql_torrentflux.sql
	sed -i -e 's@\"torrentflux\"@'\"$dbname\"'@' /usr/html/tf/config.php
	sed -i -e 's@\"root\"@'\"$dbuser\"'@' /usr/html/tf/config.php
	sed -i -e 's@\"\"@'\"$dbuserpass\"'@' /usr/html/tf/config.php
	chmod 777 /usr/html/tf/downloads
	rm -rf /usr/html/torrentflux_2.4 /usr/html/torrentflux_2.4.tar.gz

else if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[zZ]'` -gt 0 ]; then
	
	apt-get -y install python-software-properties unrar-free ffmpeg ncurses-dev libncurses-dev libsigc++ subversion screen
	mkdir -p /tmp/pkgs
	cd /tmp/pkgs
	svn co http://xmlrpc-c.svn.sourceforge.net/svnroot/xmlrpc-c/advanced xmlrpc-c
	cd /tmp/pkgs/xmlrpc-c
	./configure --prefix=/usr --libdir=/usr/lib
	make
	make install
	
	wget -O /tmp/pkgs/libzen0_0.4.28-1_i386.Debian_6.0.deb http://repo.regolithmedia.co.id/files/libzen0_0.4.28-1_i386.Debian_6.0.deb
	wget -O /tmp/pkgs/libmediainfo0_0.7.61-1_i386.Debian_6.0.deb http://repo.regolithmedia.co.id/files/libmediainfo0_0.7.61-1_i386.Debian_6.0.deb
	wget -O /tmp/pkgs/mediainfo_0.7.61-1_i386.Debian_6.0.deb http://repo.regolithmedia.co.id/files/mediainfo_0.7.61-1_i386.Debian_6.0.deb
	
	dpkg -i /tmp/pkgs/libzen0_0.4.28-1_i386.Debian_6.0.deb
	dpkg -i /tmp/pkgs/libmediainfo0_0.7.61-1_i386.Debian_6.0.deb
	dpkg -i /tmp/pkgs/mediainfo_0.7.61-1_i386.Debian_6.0.deb
	
	wget -O /tmp/pkgs/libtorrent-0.12.6.tar.gz http://repo.regolithmedia.co.id/files/libtorrent-0.12.6.tar.gz
	tar -C /tmp/pkgs/ -zxvf /tmp/pkgs/libtorrent-0.12.6.tar.gz
	cd /tmp/pkgs/libtorrent-0.12.6
	./configure --prefix=/usr --libdir=/usr/lib
	make
	make install
	
	wget -O /tmp/pkgs/rtorrent-0.8.6.tar.gz http://repo.regolithmedia.co.id/files/rtorrent-0.8.6.tar.gz
	tar -C /tmp/pkgs/ -zxvf /tmp/pkgs/rtorrent-0.8.6.tar.gz
	cd /tmp/pkgs/rtorrent-0.8.6
	./configure --with-xmlrpc-c=/usr/bin/xmlrpc-c-config
	make
	make install
	
echo "
server.modules += ( \"mod_scgi\" )
scgi.server = ( \"/RPC2\" =>
  ( \"127.0.0.1\" =>
    (
      \"host\" => \"127.0.0.1\",
      \"port\" => 5000,
      \"check-local\" => \"disable\"
    )
  )
)" >> /etc/lighttpd/lighttpd.conf

wget -O /tmp/pkgs/rutorrent-3.4.tar.gz http://repo.regolithmedia.co.id/files/rutorrent-3.4.tar.gz
tar -C /usr/html -zxvf /tmp/pkgs/rutorrent-3.4.tar.gz
mv /usr/html/rutorrent /usr/html/rt
wget -O /tmp/pkgs/plugins-3.4.tar.gz http://repo.regolithmedia.co.id/files/plugins-3.4.tar.gz
tar -C /usr/html/rt -zxvf /tmp/pkgs/plugins-3.4.tar.gz

mkdir -p /home/$wwwdir/rtorrent/downloads
mkdir -p /home/$wwwdir/rtorrent/session
mkdir -p /home/$wwwdir/rtorrent/watch

wget -O /etc/init.d/rtorrent http://repo.regolithmedia.co.id/txt/rtorrent
sed -i "s/seruu/$wwwdir/g" /etc/init.d/rtorrent
chmod +x /etc/init.d/rtorrent
echo "/etc/init.d/rtorrent start" >> /etc/init.d/rc.local

wget -O /home/$wwwdir/.rtorrent.rc http://repo.regolithmedia.co.id/txt/rtorrent.rc
sed -i "s/seruu/$wwwdir/g" /home/$wwwdir/.rtorrent.rc

chown -R $wwwdir:$wwwdir /usr/html/rt/
chown -R $wwwdir:$wwwdir /home/$wwwdir/.rtorrent.rc
chmod -R 775 /home/$wwwdir
chown -R $wwwdir.$wwwdir /home/$wwwdir/rtorrent
/etc/init.d/rtorrent start

rm -rf /tmp/pkgs
fi
fi
fi

/etc/init.d/lighttpd restart
/etc/init.d/php-fpm restart
sleep 2
echo ""
if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[rR]'` -gt 0 ]; then
echo "====================================================================="
echo "Access Rapidleech: http://$MARKAS/rl"
echo "====================================================================="
else if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[tT]'` -gt 0 ]; then
echo "====================================================================="
echo "Access Torrentflux: http://$MARKAS/tf"
echo "Torrentflux Database Name: $dbname"
echo "Torrentflux Database Username: $dbuser"
echo "Torrentflux Database Username Password: $dbuserpass"
echo "====================================================================="
else if [ "d$dipilih" = "d" ] || [ `expr "$dipilih" : '[zZ]'` -gt 0 ]; then
echo "====================================================================="
echo "Access RuTorrent: http://$MARKAS/rt"
echo ""
echo "edit /usr/html/rt/conf/config.php"
echo "find \"\$pathToExternals\", input curl and stat section with \"/usr/bin\", as below:"
echo ""
echo "\"curl\"  => '/usr/bin/curl',"
echo "\"stat\"  => '/usr/bin/stat',"
echo "====================================================================="
fi
fi
fi
echo ""
echo "BROUGHT TO YOU BY REGOLITH MEDIA"