#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

####***********************************************####
#             Lighty HTTPD Mini Installer             #
#              Dark Eagle @ Kaskus.co.id              #
#              Based On 672727's Script               #
#          Supported By Regolithmedia.co.id           #
####***********************************************####

if [ $(id -u) != "0" ]; then
    echo "Error: You must be root to use this script!"
    exit 0
fi

if [[ $(cat /etc/debian_version) != *6.* ]]; then
	echo "Error: This installer is only for Debian 6 Squeeze!"
	exit 0
fi

clear

echo "********************************************************************************"
echo "             Lighty HTTPD Mini Installer For Debian 6 Squeeze 32bit"              
echo "********************************************************************************"
echo "                              Dark Eagle @ Kaskus"
echo "                   Discussion Thread At Hosting Stuff Kaskus"
echo "               http://www.kaskus.co.id/showthread.php?t=16720198"
echo "********************************************************************************"

ARCHER=`uname -m`
if [ "$ARCHER" == "x86_64" ]; then
	tipe="x86_64"
else
    tipe="i386"
fi
MARKAS=`ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk {'print $1'} | tail -n 1`
echo ""
#Set MySQL root password
GOO=0
YRT=1
while [ $GOO -eq "0" ]; do
	read -p "Please input MySQL root password: " mysqlrootpwd
	if [ "$mysqlrootpwd" = "" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "You're not typing!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			exit 0
		fi
	else
		mysqlrootpwd="$mysqlrootpwd"
		GOO=1
	fi
done
echo ""

#Set PHP-FPM User/Group name
GOO=0
YRT=1
while [ $GOO -eq "0" ]; do
	read -p "Please input username for PHP-FPM user/group: " fpmuser
	if [ "$fpmuser" = "" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "You're not typing!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			exit 0
		fi
	else
		fpmuser="$fpmuser"
		GOO=1
	fi
done
echo ""

#Set PHP-FPM User/Group password
GOO=0
YRT=1
while [ $GOO -eq "0" ]; do
	read -p "Please input password for PHP-FPM user/group: " fpmpass
	if [ "$fpmpass" = "" ]; then
		if [ $YRT -lt 3 ]; then
			echo ""
			echo "You're not typing!"
			echo ""
			YRT=`expr $YRT + 1`
		else
			echo ""
			echo "You can try again later."
			echo ""
			exit 0
		fi
	else
		fpmpass="$fpmpass"
		GOO=1
	fi
done
echo ""

	get_char()
	{
	SAVEDSTTY=`stty -g`
	stty -echo
	stty cbreak
	dd if=/dev/tty bs=1 count=1 2> /dev/null
	stty -raw
	stty echo
	stty $SAVEDSTTY
	}
	echo ""
	echo "Press any key to start the installation!"
	char=`get_char`
	
echo ""
echo "Installation started"
sleep 1
echo ""
echo "Deactivating SELINUX"
if [ -s /etc/selinux/config ]; then
sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
fi
echo ""
sleep 3
echo "SELINUX HAS BEEN DEACTIVATED"
echo ""
echo "INSTALLING DEPENDENCIES"
echo ""
sleep 4
mkdir -p /tmp/pkgs
apt-get update -y
apt-get install -y build-essential make automake patch valgrind openssl curl libcurl4-dev libcurl3-gnutls bzip2 libbz2-dev zip unzip libxml2 libxml2-dev zlib1g zlib1g-dev libpcre3 libpcre3-dev libjpeg62 libjpeg62-dev libpng-dev libtiff4 libtiff-dev libfreetype6 libfreetype6-dev libgmp3-dev aspell libaspell-dev libpspell-dev libiconv-ruby libc-client2007e libc-client2007e-dev uw-imapd tidy libtidy-dev python python-dev
apt-get remove -y apache2 apache2-doc apache2-utils apache2.2-common bind9 php5 mysql-server
echo ""
echo "DEPENDENCIES HAVE BEEN INSTALLED"
sleep 2
echo ""
echo "INSTALLING MYSQL"
sleep 3
echo ""
wget -O /tmp/pkgs/mysql-5.1.66-linux-i686-glibc23.tar.gz http://repo.regolithmedia.co.id/files/mysql-5.1.66-linux-i686-glibc23.tar.gz
tar -C /tmp/pkgs -zxvf /tmp/pkgs/mysql-5.1.66-linux-i686-glibc23.tar.gz
mv /tmp/pkgs/mysql-5.1.66-linux-i686-glibc23 /usr/local/mysql
cd /usr/local/mysql
groupadd mysql
useradd -r -g mysql mysql
chown -R mysql .
chgrp -R mysql .
/usr/local/mysql/scripts/mysql_install_db --user=mysql
chown -R root .
chown -R mysql data
#cp /usr/local/mysql/support-files/my-huge.cnf
#cp /usr/local/mysql/support-files/my-innodb-heavy-4G.cnf
#cp /usr/local/mysql/support-files/my-large.cnf
#cp /usr/local/mysql/support-files/my-medium.cnf
cp /usr/local/mysql/support-files/my-small.cnf /etc/my.cnf
sed -i -e 's/socket/#socket/g' /etc/my.cnf
echo "" >> /etc/my.cnf
echo "[client]" >> /etc/my.cnf
echo "socket		= /var/lib/mysql/mysql.sock" >> /etc/my.cnf
echo "" >> /etc/my.cnf
echo "[mysqld]" >> /etc/my.cnf
echo "socket		= /var/lib/mysql/mysql.sock" >> /etc/my.cnf
echo "default-storage-engine=MyISAM" >> /etc/my.cnf
echo "skip-innodb" >> /etc/my.cnf
echo "skip-external-locking" >> /etc/my.cnf
cp /usr/local/mysql/support-files/mysql.server /etc/init.d/mysql
chmod +x /etc/init.d/mysql
echo "/etc/init.d/mysql start" >> /etc/init.d/rc.local
/etc/init.d/mysql start
echo ""
echo "MYSQL HAS BEEN INSTALLED, NOW SECURING MYSQL"
echo ""
sleep 3
/usr/local/mysql/bin/mysqladmin -u root password $mysqlrootpwd
echo 'DROP DATABASE 'test';' | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
echo "SET PASSWORD FOR 'root'@'127.0.0.1' = PASSWORD('$mysqlrootpwd');" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
echo "SET PASSWORD FOR 'root'@'`hostname`' = PASSWORD('$mysqlrootpwd');" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
echo "DELETE FROM mysql.user WHERE User = '';" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
echo "DROP USER ''@'%';" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
echo "DROP USER 'root'@'::1';" | /usr/local/mysql/bin/mysql -u root -p$mysqlrootpwd
/etc/init.d/mysql stop
rm -rf /usr/local/mysql/data/test
echo ""
echo "MYSQL HAS BEEN SECURED, NOW INSTALLING LIGHTTPD"
echo ""
sleep 3
wget -O /tmp/pkgs/lighttpd-1.4.31.tar.gz http://repo.regolithmedia.co.id/files/lighttpd-1.4.31.tar.gz
tar -C /tmp/pkgs -zxvf /tmp/pkgs/lighttpd-1.4.31.tar.gz
cd /tmp/pkgs/lighttpd-1.4.31
./configure --prefix=/usr --libdir=/usr/lib --enable-lfs  --with-attr --with-valgrind --with-openssl --with-openssl-includes=/usr/include/openssl --with-openssl-libs=/usr/lib/ssl --with-zlib --with-bzip2
make
make install
echo ""
echo "LIGHTTPD HAS BEEN INSTALLED, NOW INSTALLING PHP"
echo ""
sleep 3
wget -O /tmp/pkgs/autoconf-2.13.tar.gz http://repo.regolithmedia.co.id/files/autoconf-2.13.tar.gz
tar -C /tmp/pkgs -zxvf /tmp/pkgs/autoconf-2.13.tar.gz
cd /tmp/pkgs/autoconf-2.13
./configure
make && make install

wget -O /tmp/pkgs/php-5.3.18.tar.gz http://repo.regolithmedia.co.id/files/php-5.3.18.tar.gz
tar -C /tmp/pkgs -zxvf /tmp/pkgs/php-5.3.18.tar.gz
cd /tmp/pkgs/php-5.3.18
./buildconf --force
useradd $fpmuser
echo $fpmuser:$fpmpass|chpasswd
./configure --prefix=/usr --libdir=/usr/lib  --with-libdir=lib --enable-fpm --with-fpm-user=$fpmuser --with-fpm-group=$fpmuser --with-config-file-path=/usr/lib --enable-zip --with-libxml-dir=/usr/lib \
 --with-openssl=/usr --with-zlib --enable-bcmath --with-bz2 --enable-calendar --with-curl --with-curlwrappers --with-mysql=/usr/local/mysql --with-mysqli=/usr/local/mysql/bin/mysql_config \
--with-mysql-sock=/var/lib/mysql/mysql.sock --with-pdo-mysql=/usr/local/mysql --with-gd --with-jpeg-dir=/usr/lib --with-png-dir=/usr/lib --with-zlib-dir=/usr/lib--with-xpm-dir=/usr/lib --with-freetype-dir=/usr/lib \
--enable-gd-native-ttf --enable-gd-jis-conv --with-gettext=/usr/lib --with-gmp=/usr/lib --with-mhash=/usr/lib --with-imap --with-imap-ssl=/usr/lib --with-kerberos
make
make install

/tmp/pkgs/php-5.3.18/build/shtool install -c ext/phar/phar.phar /usr/bin
ln -s -f /usr/bin/phar.phar /usr/bin/phar
cp php.ini-production /usr/lib/php.ini
sed -i -e 's/;date.timezone \=/date.timezone = America\/New_York/g' /usr/lib/php.ini
sed -i -e 's/;cgi.fix_pathinfo=1/cgi.fix_pathinfo = 0/g' /usr/lib/php.ini
cp /usr/etc/php-fpm.conf.default /etc/php-fpm.conf
echo ""
echo "PHP HAS BEEN INSTALLED"
echo ""
sleep 1
echo ""
echo "FINISHING"
echo ""
sleep 3
mkdir -p /usr/html
mkdir -p /etc/lighttpd/domain
echo "$fpmuser" > /etc/lighttpd/wwwdir
cat >/etc/lighttpd/lighttpd.conf<<EOF
##===============================================================================##
## Lighttpd Configuration File ##

# Default Document Root
# This is the site that the server will revert to incase of an unknown Virtual Host
server.document-root = "/usr/html" 

# Listening Port
server.port = 80

# Lighttpd User and Group
server.username = "$fpmuser"
server.groupname = "$fpmuser"

# Acceptable Mime types
mimetype.assign = (
  ".html" => "text/html", 
  ".txt" => "text/plain",
  ".jpg" => "image/jpeg",
  ".png" => "image/png",
  ".css" => "text/css",
  ".js" => "text/js" 
)

server.modules += ("mod_fastcgi")
fastcgi.server = ( ".php" =>
  ( "localhost" =>
    (
      "host" => "127.0.0.1",
      "port" => "9000"
    )
  )
)

static-file.exclude-extensions = (".fcgi", ".php", ".rb", "~", ".inc")
index-file.names = ("index.html", "index.php")
##===============================================================================##
EOF

cat >/etc/init.d/lighttpd<<EOF
case "\$1" in
	start)
		/usr/sbin/lighttpd -f /etc/lighttpd/lighttpd.conf &
		sleep 1
		echo "Lighttpd started successfully"
		exit 1
	;;

	stop)
		pkill lighttpd
		echo "Lighttpd stopped"
		exit 1
	;;
	restart)
		echo "Stopping Lighttpd"
		pkill lighttpd
		sleep 1
		echo "Starting Lighttpd"
		/usr/sbin/lighttpd -f /etc/lighttpd/lighttpd.conf &
		sleep 1
		echo "Lighttpd restarted successfully"
		exit 1
	;;
	*)
		echo "Usage: start - stop - restart"
		exit 1
	;;
esac
EOF

cat >/etc/init.d/php-fpm<<EOF
case "\$1" in
	start)
		/usr/sbin/php-fpm --fpm-config /etc/php-fpm.conf
		echo "PHP-FPM started successfully"
		exit 1
	;;

	stop)
		pkill php-fpm
		echo "PHP-FPM stopped"
		exit 1
	;;
	restart)
		echo "Stopping php-fpm"
		pkill php-fpm
		sleep 1
		echo "Starting php-fpm"
		/usr/sbin/php-fpm --fpm-config /etc/php-fpm.conf
		sleep 1
		echo "PHP-FPM restarted successfully"
		exit 1
	;;
	*)
		echo "Usage: start - stop - restart"
		exit 1
	;;
esac
EOF

chmod +x /etc/init.d/lighttpd /etc/init.d/php-fpm
echo "/etc/init.d/lighttpd start" >> /etc/init.d/rc.local
echo "/etc/init.d/php-fpm start" >> /etc/init.d/rc.local

/etc/init.d/lighttpd start
/etc/init.d/php-fpm start
/etc/init.d/mysql start
rm -rf /tmp/pkgs

cat >/usr/html/phpinfo.php<<EOF
<?php phpinfo(); ?>
EOF

cat >/usr/html/index.html<<EOF

<html>
<head>
<title>NginX Auto Installer V1.3.14 - Powered By Servers Review dot Net</title>
</head>
<body>
<center><h3>R Ya Ready 2 Fly Light?!</h3>
<img src="http://www.lighttpd.net/light_logo.png" /><br /><br />
Powered By: <a href="http://www.regolithmedia.co.id">Regolith Media</a><br />
Kaskus Thread: <a href="http://www.kaskus.co.id/showthread.php?t=16720198">http://www.kaskus.co.id/showthread.php?t=16720198</a></center>
</body>
</html>

EOF

echo ""
echo "INSTALLATION HAS BEEN FINISHED"
echo ""
echo ""
echo "====================================================================="
echo "PHPINFO: http://$MARKAS/phpinfo.php"
echo "IP ACCESS DIR: /usr/html"
echo "MySQL Root Password: $mysqlrootpwd"
echo "PHPFPM/Lighttpd User / Group: $fpmuser"
echo "PHPFPM/Lighttpd User / Group Password: $fpmpass"
echo "====================================================================="
echo ""
echo "BROUGHT TO YOU BY REGOLITH MEDIA"