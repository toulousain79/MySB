1.0.4 (August 28, 2012)
-----------------------

 * Fixed the Twig tag to avoid a fatal error when left unclosed
 * Added the HashableInterface for non-serialiable filters
 * Fixed a bug for compass on windows

1.0.3 (March 2, 2012)
---------------------

 * Added "boring" option to Compass filter
 * Fixed accumulation of load paths in Compass filter
 * Fixed issues in CssImport and CssRewrite filters

1.0.2 (August 26, 2011)
-----------------------

 * Twig 1.2 compatibility
 * Fixed filtering of large LessCSS assets
 * Fixed escaping of commands on Windows
 * Misc fixes to Compass filter
 * Removed default CssEmbed charset

1.0.1 (July 15, 2011)
---------------------

 * Fixed Twig error handling
 * Removed use of STDIN
 * Added inheritance of environment variables
 * Fixed Compass on Windows
 * Improved escaping of commands

1.0.0 (July 10, 2011)
---------------------

 * Initial release
