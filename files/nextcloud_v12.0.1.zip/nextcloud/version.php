<?php 
$OC_Version = array(12,0,1,5);
$OC_VersionString = '12.0.1';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '11.0' => true,
    '12.0' => true,
  ),
  'owncloud' => 
  array (
    '10.0.0.12' => true,
    '10.0.1.5' => true,
    '10.0.2.1' => true,
  ),
);
$OC_Build = '2017-08-06T18:56:23+00:00 bfca9fbf115741e47a847ddb0116de1f82e8ba8d';
$vendor = 'nextcloud';
