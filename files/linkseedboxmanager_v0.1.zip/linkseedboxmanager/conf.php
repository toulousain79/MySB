<?php

/* 
Indiquez l'url complète de seedbox-manager
 */
$url = 'http://seedbox-manager.ndd.tld';

$onglet = true;
