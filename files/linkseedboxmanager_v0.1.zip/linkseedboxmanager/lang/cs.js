theUILang.linkseedboxmanager = "Gérer votre seedbox avec Seedbox-Manager";

thePlugins.get("linkseedboxmanager").langLoaded();