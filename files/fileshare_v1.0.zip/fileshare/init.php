<?php

	$theSettings->registerPlugin("fileshare");
