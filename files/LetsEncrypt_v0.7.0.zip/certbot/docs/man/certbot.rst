.. program-output:: certbot --help all
