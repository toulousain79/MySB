:mod:`certbot.plugins.standalone`
-------------------------------------

.. automodule:: certbot.plugins.standalone
   :members:
