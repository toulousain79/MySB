:mod:`certbot_nginx.obj`
----------------------------

.. automodule:: certbot_nginx.obj
   :members:
