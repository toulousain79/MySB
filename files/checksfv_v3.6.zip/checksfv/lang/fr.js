 /*
 * PLUGIN CHECKSFV
 *
 * English language file.
 *
 * Author: AceP1983
 */

 theUILang.checksfv		= "Vérification SFV";
 