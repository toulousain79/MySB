<?php

$pathToExternals['cksfv'] = '';		// Something like /usr/bin/cksfv. If empty, will be found in PATH.
