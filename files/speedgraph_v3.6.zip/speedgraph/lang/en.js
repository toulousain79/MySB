/*
 * PLUGIN Speed Graph
 *
 * English language file.
 *
 * Author: AceP1983
 */
 theUILang.spdGraphLength = "Monitoring Time";
 theUILang.spdGraphName = "Speed Graph";

thePlugins.get("speedgraph").langLoaded();