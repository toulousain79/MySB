/*
 * PLUGIN Graphique de vitesse
 *
 * English language file.
 *
 * Author: AceP1983
 */
 theUILang.spdGraphLength = "Surveillance du temps";
 theUILang.spdGraphName = "Graphique de vitesse";

thePlugins.get("speedgraph").langLoaded();