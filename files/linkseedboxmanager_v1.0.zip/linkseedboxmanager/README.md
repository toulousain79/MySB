##Description
Le plugin Linkseedboxmanager permet de faire un lien dans la toolbar de rutorrent pour le manager disponible ici : [Lien Seedbox-manager](https://github.com/Magicalex/seedbox-manager/)


Auteur : Hydrog3n (reprise de [Linkcakebox](https://github.com/Cakebox/linkcakebox/) de Magicalex)
