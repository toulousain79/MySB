#ifndef START_RTORRENT_H
#define START_RTORRENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Prototypes
void start_rtorrent(char nickname[]);

#endif
