#ifndef KILL_IRSSI_H
#define KILL_IRSSI_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Prototypes
void screen_irssi_kill(char nickname[]);

#endif
