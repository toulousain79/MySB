theUILang.nfoView		= "NFO Viewer";
theUILang.nfoNotFound = "Could not open NFO";
theUILang.nfoNotFoundTitle = "ERROR";

thePlugins.get("nfo").langLoaded();
