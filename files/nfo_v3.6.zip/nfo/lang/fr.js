theUILang.nfoView		= "Visionneuse NFO";
theUILang.nfoNotFound = "Impossible d'ouvrir le NFO";
theUILang.nfoNotFoundTitle = "ERREUR";

thePlugins.get("nfo").langLoaded();
