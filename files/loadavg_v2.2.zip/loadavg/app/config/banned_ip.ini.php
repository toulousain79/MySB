; <?php exit(); __halt_compiler(); ?>
banned=