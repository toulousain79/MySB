﻿theUILang.linkcakebox = "Streamer vos fichiers avec Cakebox";
theUILang.linkcakeboxmenu = "Lire dans Cakebox";

thePlugins.get("linkcakebox").langLoaded();