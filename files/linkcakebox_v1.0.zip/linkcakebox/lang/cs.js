theUILang.linkcakebox = "Watch your files with Cakebox";
theUILang.linkcakeboxmenu = "Watch in Cakebox";

thePlugins.get("linkcakebox").langLoaded();