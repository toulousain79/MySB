##Description
Linkcakebox est un  plugin rutorrent pour cakebox v2.x et Cakebox-light.  
Au clic sur le bouton de la toolbar un nouvel onglet s'ouvre vers la page index de cakebox.  
Un autre lien est présent dans l'onglet "fichier" qui redirige vers la page cakebox/watch.php du fichier concerné.  
Le thème Oblivion est pris en charge.

![plugin cakebox](http://images.mondedie.fr/images/jhg6c.png)

Pour l'installation et la configuration suivre ce lien
[wiki linkcakebox](https://github.com/Cakebox/linkcakebox/wiki/Linkcakebox-plugin-pour-rutorrent)


Auteur : Magicalex
