#ifndef KILL_RTORRENT_H
#define KILL_RTORRENT_H

// Librairies
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Prototypes
void rtorrent_kill (char nickname[]);
void screen_kill (char nickname[]);
void supprLock (char nickname[]);

#endif
