
#ifndef __PLUGIN_OPTIONS_H__
#define __PLUGIN_OPTIONS_H__ 1

#include "plugin_support.h"

int plugin_options_parse_str(DCPluginSupportContext *dpcs_context,
                             char * const str);

#endif
