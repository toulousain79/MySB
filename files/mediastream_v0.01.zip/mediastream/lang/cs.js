theUILang.mediastream	= 'Video player';
