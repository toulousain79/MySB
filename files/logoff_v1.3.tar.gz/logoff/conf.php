<?php
// logoff URL (full url, e.g. http://12.34.56.78/ or http://www.google.com/)
$logoffURL = "http://google.com/";

// after how many miliseconds should the logoff request be aborted?
// note: too low and you won't be logged off, too high and you will get the auth popup
$abortMs = 1000;

// allowed switch list (comma seperated user list)
$allowSwitch = "scars,user1,user2";
?>
