theUILang.logoff             = "Déconnecter";
theUILang.logoffUsername     = "Login";
theUILang.logoffPassword     = "Mdp";
theUILang.logoffSwitch       = "Changer d'utilisateur";
theUILang.logoffPrompt       = "Voulez-vous déconnecter ou annuler?";
theUILang.logoffSwitchPrompt = "Voulez-vous changer d'utilisateur, vous déconnecter ou annuler?";
theUILang.logoffEmpty        = "<-- ne peut pas être vide";

thePlugins.get("logoff").langLoaded();
