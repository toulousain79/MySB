theUILang.logoff             = "Log uit";
theUILang.logoffUsername     = "Gebruikersnaam";
theUILang.logoffPassword     = "Wachtwoord";
theUILang.logoffSwitch       = "Wissel gebruiker";
theUILang.logoffPrompt       = "Wil je uitloggen of deze handeling annuleren?";
theUILang.logoffSwitchPrompt = "Wil je van gebruiker wisselen, uitloggen of deze handeling annuleren?";
theUILang.logoffEmpty        = "<-- kan niet leeg zijn";

thePlugins.get("logoff").langLoaded();
