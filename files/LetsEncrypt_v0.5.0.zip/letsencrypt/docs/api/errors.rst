:mod:`certbot.errors`
-------------------------

.. automodule:: certbot.errors
   :members:
