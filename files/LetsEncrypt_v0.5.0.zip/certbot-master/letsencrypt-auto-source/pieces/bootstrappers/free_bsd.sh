BootstrapFreeBsd() {
  $SUDO pkg install -Ay \
    python \
    py27-virtualenv \
    augeas \
    libffi
}
