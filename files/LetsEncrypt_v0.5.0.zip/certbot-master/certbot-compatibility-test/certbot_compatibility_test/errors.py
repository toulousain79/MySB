"""Certbot compatibility test errors"""


class Error(Exception):
    """Generic Certbot compatibility test error"""
