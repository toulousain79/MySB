﻿/*
 * PLUGIN EDIT
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.EditTrackers 		= "编辑 Torrent...";
 theUILang.EditTorrentProperties	= "Torrent 属性";
 theUILang.errorAddTorrent		= "Error adding torrent file";
 theUILang.errorWriteTorrent		= "Error writing torrent file";
 theUILang.errorReadTorrent		= "Error reading torrent file";
 theUILang.cantFindTorrent		= "Source torrent file for this download not found."

thePlugins.get("edit").langLoaded();