﻿/*
 * PLUGIN EXTRATIO
 *
 * Hungarian language file.
 *
 * Author: 
 */

 theUILang.ratioRulesManager	= "Rules Manager";
 theUILang.mnu_ratiorule	= "Ratio Rules";
 theUILang.ratAddRule		= "Add";
 theUILang.ratDelRule		= "Delete";
 theUILang.ratUpRule		= "Up";
 theUILang.ratDownRule		= "Down";
 theUILang.ratioIfLegend	= "If";
 theUILang.ratLabelContain	= "Torrent Label contains";
 theUILang.ratTrackerContain	= "One of torrent's tracker URLs contains";
 theUILang.ratTrackerPublic	= "All torrent's trackers are public";
 theUILang.ratTrackerPrivate	= "One of torrent's trackers is private";
 theUILang.ratioThenLegend	= "Then";
 theUILang.setRatioTo		= "Set ratio to";
 theUILang.setChannelTo 	= "Set throttle to";
 theUILang.ratioNewRule 	= "New rule";

thePlugins.get("extratio").langLoaded();