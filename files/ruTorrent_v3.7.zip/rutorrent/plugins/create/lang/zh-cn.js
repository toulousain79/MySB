﻿/*
 * PLUGIN CREATE
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.mnu_create			= "创建 Torrent...";
 theUILang.CreateNewTorrent		= "创建新的 Torrent";
 theUILang.SelectSource 		= "选择源";
 theUILang.TorrentProperties		= "Torrent 属性";
 theUILang.PieceSize			= "块尺寸";
 theUILang.Other			= "其它";
 theUILang.StartSeeding 		= "开始做种";
 theUILang.PrivateTorrent		= "私有 Torrent";
 theUILang.torrentCreate		= "创建...";
 theUILang.BadTorrentData		= "You must fill all required fields!";
 theUILang.createExternalNotFound	= "Create plugin: Plugin will not work. Webserver user can't access external program";
 theUILang.incorrectDirectory		= "Incorrect directory";
 theUILang.cantExecExternal		= "Can't execute external program";
 theUILang.createConsole		= "控制台";
 theUILang.createErrors 		= "错误";
 theUILang.torrentSave			= "保持";
 theUILang.torrentKill			= "停止";
 theUILang.torrentKilled		= "进程已停止.";
 theUILang.recentTrackers		= "Recent trackers"; 

thePlugins.get("create").langLoaded();