﻿/*
 * PLUGIN DATADIR
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.DataDir		= "Opslaan in";
 theUILang.DataDirMove		= "Verplaats bestanden";
 theUILang.datadirDlgCaption	= "Torrent data map";
 theUILang.datadirDirNotFound	= "DataDir plugin: Ongeldige map";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operatie mislukt";

thePlugins.get("datadir").langLoaded();