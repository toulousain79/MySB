<?php

	$theSettings->registerPlugin("filemanager");
