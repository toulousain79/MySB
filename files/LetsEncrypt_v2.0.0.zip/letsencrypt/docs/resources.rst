=====================
Resources
=====================

.. include:: ../README.rst
    :start-after: tag:links-begin
    :end-before: tag:links-end
