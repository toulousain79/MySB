/*
 * PLUGIN MOBILE
 *
 * Greek language file.
 *
 * Author: 
 */

 theUILang.SortTorrents    = "Sort torrents by";
 theUILang.acs             = "Ascending";
 theUILang.decs            = "Descending";

thePlugins.get("mobile").langLoaded();
