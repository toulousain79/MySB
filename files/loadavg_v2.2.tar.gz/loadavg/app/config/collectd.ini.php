; <?php exit(); __halt_compiler(); ?>
logfile = "/var/lib/collectd/csv/localhost/"
collectd = "true"
log_path = "/var/lib/collectd/csv/localhost/"
