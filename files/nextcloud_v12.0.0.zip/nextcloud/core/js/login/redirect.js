jQuery(document).ready(function() {
	$('#submit-redirect-form').trigger('click');
});
