#include "crypto_onetimeauth_poly1305.h"

size_t
crypto_onetimeauth_poly1305_bytes(void) {
    return crypto_onetimeauth_poly1305_BYTES;
}

size_t
crypto_onetimeauth_poly1305_keybytes(void) {
    return crypto_onetimeauth_poly1305_KEYBYTES;
}
