
 
 theUILang.ratiocolorName = "Ratiocolor";
 theUILang.ratiocolorColors = "Colors in hex sperated by ',' (Format: 0000ff,ff0000,...)";
 theUILang.ratiocolorLevels = "Levels seperated by ','. Must start with 0 (Format: 0,0.5,1,...)";
 theUILang.ratiocolorLengthError = "Ratiocolor: There must be the same numbers of levels and colors";
 theUILang.ratiocolorLevel0 = "Ratiocolor: The first level must be 0";
 
 thePlugins.get("ratiocolor").langLoaded();