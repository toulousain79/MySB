#include <stdio.h>

#include "abyss.h"



void 
test_abyss(void) {

    printf("Running dummy Abyss test.");

    printf("\n");
    printf("Abyss server tests done.\n");
}
