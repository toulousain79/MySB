:mod:`letsencrypt.plugins.manual`
---------------------------------

.. automodule:: letsencrypt.plugins.manual
   :members:
