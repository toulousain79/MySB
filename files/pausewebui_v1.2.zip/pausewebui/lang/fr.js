theUILang.pausewebuiPause = "Désactiver la mise à jour de l'UI..";
theUILang.pausewebuiRefresh = "Raflaîchir l'UI..";
theUILang.pausewebuiResume = "Activer la mise à jour de l'UI..";