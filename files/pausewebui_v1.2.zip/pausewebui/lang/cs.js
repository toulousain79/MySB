theUILang.pausewebuiPause = "Pause WebUI..";
theUILang.pausewebuiRefresh = "Refresh WebUI..";
theUILang.pausewebuiResume = "Resume WebUI..";