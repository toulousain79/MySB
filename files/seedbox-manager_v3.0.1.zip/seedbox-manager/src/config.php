<?php

return [
    'settings' => [
        'displayErrorDetails' => true,
        'addContentLengthHeader' => true
    ]
];
